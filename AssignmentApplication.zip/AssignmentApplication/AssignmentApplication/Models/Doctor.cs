﻿using System;
using System.Collections.Generic;

namespace AssignmentApplication.Models
{
    public partial class Doctor
    {
        public Doctor()
        {
            DoctorRatings = new HashSet<DoctorRatings>();
        }

        public int Id { get; set; }
        public string Name { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailId { get; set; }

        public virtual ICollection<DoctorRatings> DoctorRatings { get; set; }
    }
}
