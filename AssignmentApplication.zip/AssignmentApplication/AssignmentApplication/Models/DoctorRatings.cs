﻿using System;
using System.Collections.Generic;

namespace AssignmentApplication.Models
{
    public partial class DoctorRatings
    {
        public int Id { get; set; }
        public int RatingId { get; set; }
        public int DoctorId { get; set; }

        public virtual Doctor Doctor { get; set; }
        public virtual Ratings Rating { get; set; }
    }
}
