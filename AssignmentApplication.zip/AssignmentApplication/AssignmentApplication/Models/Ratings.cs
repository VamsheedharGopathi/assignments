﻿using System;
using System.Collections.Generic;

namespace AssignmentApplication.Models
{
    public partial class Ratings
    {
        public Ratings()
        {
            DoctorRatings = new HashSet<DoctorRatings>();
        }

        public int Id { get; set; }
        public int Rating { get; set; }

        public virtual ICollection<DoctorRatings> DoctorRatings { get; set; }
    }
}
