﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace AssignmentApplication.DataBase
{
    public interface IDBHelper<T> where T:class
    {
        int Insert(T insertObject);
        int Update(T updateObject);
        int Delete(T deleteObject);
        T GetByID(int ID);
        List<T> GetAll();
    }
}
