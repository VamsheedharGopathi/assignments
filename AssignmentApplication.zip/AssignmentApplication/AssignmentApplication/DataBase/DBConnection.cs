﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace AssignmentApplication.DataBase
{
    public interface IDBConnection<T> where T:class
    {
        T Connection(string ConnectionString);
    }
    public class SqlDBConnection : IDBConnection<SqlConnection>
    {
        public SqlConnection Connection(string ConnectionString)
        {
            return new SqlConnection(ConnectionString);
        }

        public SqlCommand Command()
        {
            return new SqlCommand();
        }
    }
}
