﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using AssignmentApplication.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.DataAnnotations;
using Newtonsoft.Json;

namespace AssignmentApplication.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class PatientsController : ControllerBase
    {
        AppointmentDBContext dBContext;
        public PatientsController()
        {
            dBContext = new AppointmentDBContext();
        }
        [HttpGet]
        [Route("GetAllDoctors")]
        public async Task<IActionResult> GetAllDoctors() => await Task.Run(() =>
        {
            var doctors = from d in dBContext.Doctor join 
                          dr in dBContext.DoctorRatings on d.Id equals dr.DoctorId 
                          join r in dBContext.Ratings on dr.RatingId equals r.Id
                          select new {doctor=d,rating=r.Rating };
            return Ok(doctors);
        }).ConfigureAwait(false);

        [HttpGet]
        [Route("GetDoctorByID/{ID}")]
        public async Task<IEnumerable<Doctor>> GetDoctorByID(int ID) => await Task.Run(() =>
        {
            var doctors = from d in dBContext.Doctor 
                          join r in dBContext.DoctorRatings on d.Id equals r.DoctorId
                          where d.Id==ID select d;
            return doctors;
        }).ConfigureAwait(false);

        [HttpPost]
        [Route("AddPatientInfo/{Id}")]
        public async Task<IActionResult> AddPatientInfo(Patients patients,int Id) => await Task.Run(() =>
        {
            
            dBContext.Patients.Add(patients);
            var patientsId = dBContext.SaveChanges();
            dBContext.PatientAppointMentDetails.Add(new PatientAppointMentDetails { DoctorId = Id, PatientId = patientsId });
            dBContext.SaveChanges();
            return Ok();
        }).ConfigureAwait(false);

        [HttpPost]
        [Route("Login")]
        public async Task<IActionResult> Login(Users  users) => await Task.Run(() =>
        {
            var user = from u in dBContext.Users where u.EmailId == users.EmailId && u.Password == users.Password select u;
            ObjectResult status = null ;
            if (user.Any()) { status = Ok(user); }
            else
            { status = Unauthorized(null);}
           return status;
        }).ConfigureAwait(false);

        [HttpGet]
        [Route("GetPatientInfo/{ID}")]
        public async Task GetPatientInfo(Patients patientsD) => await Task.Run(() =>
        {
            dBContext.Patients.Add(patientsD);
            dBContext.SaveChanges();
        }).ConfigureAwait(false);

        [HttpGet]
        [Route("GetDoctorsAppoinment/{Id}")]
        public async Task<IActionResult> GetDoctorsAppoinment(int Id) => await Task.Run(() =>
        {
            var patients = from d in dBContext.Doctor
                           join pa in dBContext.PatientAppointMentDetails on d.Id equals pa.DoctorId
                           join p in dBContext.Patients on pa.PatientId equals p.Id
                           where d.Id == Id
                           select p;
            return Ok(patients);
        }).ConfigureAwait(false);

    }
}
