import { Component,OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
  selectedDoctor: string = "";
  selectedDoctorID: number = 0;
  patients = new FormGroup({
    name: new FormControl(''),
    phoneNumber: new FormControl(''),
    address: new FormControl(''),
    description: new FormControl(''),
    emailId: new FormControl(''),
    doctor: new FormControl(this.selectedDoctor)
  });
  doctors: any = [];
  
  constructor(private http: HttpClient, @Inject('BASE_URL')private baseUrl: string) {
    http.get(baseUrl + 'Patients/GetAllDoctors').subscribe(result => {
      this.doctors = result;
    }, error => console.error(error));
  }

  ngOnInit() {

  }

  selectDoctor = (ID: number) => {
    this.selectedDoctorID = ID;
    let selectedDoctor = this.doctors.filter((e) => {
        return e.doctor.id === ID;
    });
    this.selectedDoctor = selectedDoctor[0].doctor.name
  }

  submit = () => {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    this.http.post<any>(this.baseUrl + 'Patients/AddPatientInfo/' + this.selectedDoctorID, JSON.stringify(this.patients.value), { headers: headers }).subscribe(result => {
      this.doctors = result;
    }, error => console.error(error));
  }
  
}

