import { Component, Inject, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';

@Component({
  selector: 'app-fetch-data',
  templateUrl: './fetch-data.component.html'
})
export class FetchDataComponent implements OnInit {
  ID: number = 0;
  patients: any[];
  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string, private route: ActivatedRoute) {
    route.params.subscribe(params => this.ID = params['id']);
    http.get<any[]>(baseUrl + 'Patients/GetDoctorsAppoinment/' + this.ID).subscribe(result => {
      this.patients = result;
    }, error => console.error(error));
    
  }

  ngOnInit() {
    
  }
  accepted() { }
  rejected() { }
  
}
