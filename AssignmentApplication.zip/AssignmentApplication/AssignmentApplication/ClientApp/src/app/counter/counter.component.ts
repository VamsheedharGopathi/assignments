import { Component, OnInit, Inject } from '@angular/core';
import { FormGroup, FormControl } from '@angular/forms';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-counter-component',
  templateUrl: './counter.component.html'
})
export class CounterComponent {
  constructor(private http: HttpClient, @Inject('BASE_URL') private baseUrl: string, private router: Router)  { }
  login = new FormGroup({
    emailId: new FormControl(''),
    password: new FormControl('')
  });

  submit = () => {
    let headers = new HttpHeaders({
      'Content-Type': 'application/json'
    });
    this.http.post<any>(this.baseUrl + 'Patients/Login', JSON.stringify(this.login.value), { headers: headers }).subscribe(result => {
      this.router.navigate(['/fetch-data/' + result[0].id]);
    }, error => console.error(error));
  }
}
